var searchData=
[
  ['strutture_2eh_0',['strutture.h',['../strutture_8h.html',1,'']]]
];
