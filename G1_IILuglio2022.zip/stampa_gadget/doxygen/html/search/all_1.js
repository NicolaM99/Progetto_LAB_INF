var searchData=
[
  ['chiusura_5fprogramma_0',['chiusura_programma',['../funzioni_8c.html#a96df8fdf079a2df508c10b802e217f78',1,'chiusura_programma():&#160;funzioni.c'],['../funzioni_8h.html#a96df8fdf079a2df508c10b802e217f78',1,'chiusura_programma():&#160;funzioni.c']]],
  ['cliente_1',['cliente',['../structcliente.html',1,'']]],
  ['codice_2',['codice',['../structgadget.html#a5b3eddf42a0877307f85f61eec62839d',1,'gadget']]],
  ['codice_5fcliente_3',['codice_cliente',['../structordine.html#a1167ce28f7782fbc7e4869d8073a153f',1,'ordine']]],
  ['codice_5fgadget_4',['codice_gadget',['../structordine.html#a2baf2518806407c32ae0e43d4c13b59a',1,'ordine']]],
  ['cognome_5',['cognome',['../structvenditore.html#ac977b30bfc3e91c620a6a0fe2d135204',1,'venditore']]],
  ['colore_6',['colore',['../structgadget.html#a4a5673d652befa44710b5ab5182ebf9e',1,'gadget']]],
  ['commento_7',['commento',['../structordine.html#a11ec046786fbcd6a811dd44847013679',1,'ordine']]],
  ['controlla_5fcliente_8',['controlla_cliente',['../funzioni_8c.html#aa6aa6088e00ece5334c71ac82836ce1c',1,'controlla_cliente(FILE *file, int userID):&#160;funzioni.c'],['../funzioni_8h.html#aa6aa6088e00ece5334c71ac82836ce1c',1,'controlla_cliente(FILE *file, int userID):&#160;funzioni.c']]],
  ['controlla_5ffloat_9',['controlla_float',['../funzioni_8c.html#a26a35c05b20935e320fed842a116b336',1,'controlla_float(char *stringa):&#160;funzioni.c'],['../funzioni_8h.html#a26a35c05b20935e320fed842a116b336',1,'controlla_float(char *stringa):&#160;funzioni.c']]],
  ['controlla_5fintero_10',['controlla_intero',['../funzioni_8c.html#a14d616d54516b1ed4428921c3656d4b2',1,'controlla_intero(char *stringa):&#160;funzioni.c'],['../funzioni_8h.html#a14d616d54516b1ed4428921c3656d4b2',1,'controlla_intero(char *stringa):&#160;funzioni.c']]],
  ['controlla_5fvenditore_11',['controlla_venditore',['../funzioni_8c.html#a5df3398976d7044d08cd6bb264882901',1,'controlla_venditore(FILE *file, int userID):&#160;funzioni.c'],['../funzioni_8h.html#a5df3398976d7044d08cd6bb264882901',1,'controlla_venditore(FILE *file, int userID):&#160;funzioni.c']]],
  ['costo_12',['costo',['../structordine.html#add56c7cfa6a4d78700cd29c82d1990e9',1,'ordine']]]
];
