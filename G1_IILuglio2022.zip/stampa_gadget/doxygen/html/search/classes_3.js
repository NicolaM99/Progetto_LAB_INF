var searchData=
[
  ['venditore_0',['venditore',['../structvenditore.html',1,'']]]
];
