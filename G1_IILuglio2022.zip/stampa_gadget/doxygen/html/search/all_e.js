var searchData=
[
  ['scelta_5futente_0',['scelta_utente',['../menu_8c.html#a437b75f26b2521f40d5e45c512e364e1',1,'scelta_utente():&#160;menu.c'],['../menu_8h.html#a437b75f26b2521f40d5e45c512e364e1',1,'scelta_utente():&#160;menu.c']]],
  ['sede_1',['sede',['../structcliente.html#ae42b2978854df2f4887aae9ec13dabec',1,'cliente']]],
  ['statistiche_5fgadget_2',['statistiche_gadget',['../funzioni_8c.html#a73587dd6814c2ccaf120cca679f59bb0',1,'statistiche_gadget(FILE *fileGadget):&#160;funzioni.c'],['../funzioni_8h.html#a73587dd6814c2ccaf120cca679f59bb0',1,'statistiche_gadget(FILE *fileGadget):&#160;funzioni.c']]],
  ['storico_5fordini_3',['storico_ordini',['../funzioni_8c.html#abe31de713cdf0c0867ac802f206376a9',1,'storico_ordini(FILE *fileOrdini):&#160;funzioni.c'],['../funzioni_8h.html#abe31de713cdf0c0867ac802f206376a9',1,'storico_ordini(FILE *fileOrdini):&#160;funzioni.c']]],
  ['strutture_2eh_4',['strutture.h',['../strutture_8h.html',1,'']]]
];
