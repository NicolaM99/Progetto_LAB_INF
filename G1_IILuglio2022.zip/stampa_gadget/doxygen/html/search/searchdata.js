var indexSectionsWithContent =
{
  0: "acdefgilmnopqrstuv",
  1: "cgov",
  2: "fgms",
  3: "aceimrsv",
  4: "cdeinpqstuv",
  5: "lm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

