var searchData=
[
  ['registra_5fcliente_0',['registra_cliente',['../funzioni_8c.html#a23eea9c64834a35f06f302e8bd6359fb',1,'registra_cliente(FILE *fileClienti):&#160;funzioni.c'],['../funzioni_8h.html#a23eea9c64834a35f06f302e8bd6359fb',1,'registra_cliente(FILE *fileClienti):&#160;funzioni.c']]],
  ['registra_5fvenditore_1',['registra_venditore',['../funzioni_8c.html#aab703521d8b6fda56787e8364f575754',1,'registra_venditore(FILE *fileVenditori):&#160;funzioni.c'],['../funzioni_8h.html#aab703521d8b6fda56787e8364f575754',1,'registra_venditore(FILE *fileVenditori):&#160;funzioni.c']]],
  ['ricerca_5fgadget_2',['ricerca_gadget',['../funzioni_8c.html#a2e17adb07dff3c379af31c1fa6d62ce5',1,'ricerca_gadget(FILE *fileGadget, char nome_gadget[], int codice):&#160;funzioni.c'],['../funzioni_8h.html#a2e17adb07dff3c379af31c1fa6d62ce5',1,'ricerca_gadget(FILE *fileGadget, char nome_gadget[], int codice):&#160;funzioni.c']]]
];
