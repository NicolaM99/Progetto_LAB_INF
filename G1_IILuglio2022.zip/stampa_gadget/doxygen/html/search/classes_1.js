var searchData=
[
  ['gadget_0',['gadget',['../structgadget.html',1,'']]]
];
