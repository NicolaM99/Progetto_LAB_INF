var searchData=
[
  ['descrizione_0',['descrizione',['../structgadget.html#ae8a54855e881ce5fdfc3a0fa68ac9fae',1,'gadget']]]
];
