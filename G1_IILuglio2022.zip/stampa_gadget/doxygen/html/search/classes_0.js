var searchData=
[
  ['cliente_0',['cliente',['../structcliente.html',1,'']]]
];
