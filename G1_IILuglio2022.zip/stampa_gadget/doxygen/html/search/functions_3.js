var searchData=
[
  ['input_5ffloat_0',['input_float',['../funzioni_8c.html#a3622974e9814dd0e0a54e96e40dd7bc8',1,'input_float(const char *label):&#160;funzioni.c'],['../funzioni_8h.html#a3622974e9814dd0e0a54e96e40dd7bc8',1,'input_float(const char *label):&#160;funzioni.c']]],
  ['input_5fintero_1',['input_intero',['../funzioni_8c.html#a7a63613f35e5fd4d13323f82d54621fc',1,'input_intero(const char *label):&#160;funzioni.c'],['../funzioni_8h.html#a7a63613f35e5fd4d13323f82d54621fc',1,'input_intero(const char *label):&#160;funzioni.c']]]
];
