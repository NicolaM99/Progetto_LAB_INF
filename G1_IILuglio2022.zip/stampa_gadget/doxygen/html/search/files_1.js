var searchData=
[
  ['gadget_2ec_0',['gadget.c',['../gadget_8c.html',1,'']]]
];
