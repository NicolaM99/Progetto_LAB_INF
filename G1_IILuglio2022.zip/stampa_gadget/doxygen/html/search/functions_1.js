var searchData=
[
  ['chiusura_5fprogramma_0',['chiusura_programma',['../funzioni_8c.html#a96df8fdf079a2df508c10b802e217f78',1,'chiusura_programma():&#160;funzioni.c'],['../funzioni_8h.html#a96df8fdf079a2df508c10b802e217f78',1,'chiusura_programma():&#160;funzioni.c']]],
  ['controlla_5fcliente_1',['controlla_cliente',['../funzioni_8c.html#aa6aa6088e00ece5334c71ac82836ce1c',1,'controlla_cliente(FILE *file, int userID):&#160;funzioni.c'],['../funzioni_8h.html#aa6aa6088e00ece5334c71ac82836ce1c',1,'controlla_cliente(FILE *file, int userID):&#160;funzioni.c']]],
  ['controlla_5ffloat_2',['controlla_float',['../funzioni_8c.html#a26a35c05b20935e320fed842a116b336',1,'controlla_float(char *stringa):&#160;funzioni.c'],['../funzioni_8h.html#a26a35c05b20935e320fed842a116b336',1,'controlla_float(char *stringa):&#160;funzioni.c']]],
  ['controlla_5fintero_3',['controlla_intero',['../funzioni_8c.html#a14d616d54516b1ed4428921c3656d4b2',1,'controlla_intero(char *stringa):&#160;funzioni.c'],['../funzioni_8h.html#a14d616d54516b1ed4428921c3656d4b2',1,'controlla_intero(char *stringa):&#160;funzioni.c']]],
  ['controlla_5fvenditore_4',['controlla_venditore',['../funzioni_8c.html#a5df3398976d7044d08cd6bb264882901',1,'controlla_venditore(FILE *file, int userID):&#160;funzioni.c'],['../funzioni_8h.html#a5df3398976d7044d08cd6bb264882901',1,'controlla_venditore(FILE *file, int userID):&#160;funzioni.c']]]
];
