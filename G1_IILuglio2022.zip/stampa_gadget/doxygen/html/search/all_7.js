var searchData=
[
  ['lunghezza_5fchar_5fstruct_0',['LUNGHEZZA_CHAR_STRUCT',['../funzioni_8h.html#a5a9feb718f2b5d02ea4976a99fe65138',1,'funzioni.h']]]
];
