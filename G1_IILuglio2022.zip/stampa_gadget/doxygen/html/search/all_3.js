var searchData=
[
  ['effettua_5fordine_0',['effettua_ordine',['../funzioni_8c.html#ab82db5c4d3d587ed8595fc05b8fa7d80',1,'effettua_ordine(FILE *fileClienti, FILE *fileOrdini, FILE *fileGadget):&#160;funzioni.c'],['../funzioni_8h.html#ab82db5c4d3d587ed8595fc05b8fa7d80',1,'effettua_ordine(FILE *fileClienti, FILE *fileOrdini, FILE *fileGadget):&#160;funzioni.c']]],
  ['elimina_5fcliente_1',['elimina_cliente',['../funzioni_8c.html#a59bd3ad7068e1c81540636a0ba6df8c4',1,'elimina_cliente(FILE *fileClienti):&#160;funzioni.c'],['../funzioni_8h.html#a59bd3ad7068e1c81540636a0ba6df8c4',1,'elimina_cliente(FILE *fileClienti):&#160;funzioni.c']]],
  ['elimina_5fgadget_2',['elimina_gadget',['../funzioni_8c.html#a51df04f19da107b158be76936087756d',1,'elimina_gadget(FILE *fileGadget):&#160;funzioni.c'],['../funzioni_8h.html#a51df04f19da107b158be76936087756d',1,'elimina_gadget(FILE *fileGadget):&#160;funzioni.c']]],
  ['eliminato_3',['eliminato',['../structgadget.html#ac7f8bc8482afe78ec4788b0974774003',1,'gadget']]],
  ['evaso_4',['evaso',['../structordine.html#ab25b8db148db306202e3ed41aefe082c',1,'ordine']]]
];
