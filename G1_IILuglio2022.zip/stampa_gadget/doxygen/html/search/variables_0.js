var searchData=
[
  ['codice_0',['codice',['../structgadget.html#a5b3eddf42a0877307f85f61eec62839d',1,'gadget']]],
  ['codice_5fcliente_1',['codice_cliente',['../structordine.html#a1167ce28f7782fbc7e4869d8073a153f',1,'ordine']]],
  ['codice_5fgadget_2',['codice_gadget',['../structordine.html#a2baf2518806407c32ae0e43d4c13b59a',1,'ordine']]],
  ['cognome_3',['cognome',['../structvenditore.html#ac977b30bfc3e91c620a6a0fe2d135204',1,'venditore']]],
  ['colore_4',['colore',['../structgadget.html#a4a5673d652befa44710b5ab5182ebf9e',1,'gadget']]],
  ['commento_5',['commento',['../structordine.html#a11ec046786fbcd6a811dd44847013679',1,'ordine']]],
  ['costo_6',['costo',['../structordine.html#add56c7cfa6a4d78700cd29c82d1990e9',1,'ordine']]]
];
