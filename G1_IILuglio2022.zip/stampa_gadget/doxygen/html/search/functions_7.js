var searchData=
[
  ['visualizza_5fcliente_0',['visualizza_cliente',['../funzioni_8c.html#aa7b1b645229f4c13758757fc8b859ff0',1,'visualizza_cliente(FILE *fileClienti):&#160;funzioni.c'],['../funzioni_8h.html#aa7b1b645229f4c13758757fc8b859ff0',1,'visualizza_cliente(FILE *fileClienti):&#160;funzioni.c']]],
  ['visualizza_5fgadget_1',['visualizza_gadget',['../funzioni_8c.html#a485d543370fe1851799009f822a3f22a',1,'visualizza_gadget(FILE *fileGadget):&#160;funzioni.c'],['../funzioni_8h.html#a485d543370fe1851799009f822a3f22a',1,'visualizza_gadget(FILE *fileGadget):&#160;funzioni.c']]],
  ['visualizza_5fi_5ftuoi_5fordini_2',['visualizza_i_tuoi_ordini',['../funzioni_8c.html#a70d334b525d704fcde3a60dec061b0e5',1,'visualizza_i_tuoi_ordini(FILE *fileOrdini, FILE *fileGadget):&#160;funzioni.c'],['../funzioni_8h.html#a70d334b525d704fcde3a60dec061b0e5',1,'visualizza_i_tuoi_ordini(FILE *fileOrdini, FILE *fileGadget):&#160;funzioni.c']]]
];
