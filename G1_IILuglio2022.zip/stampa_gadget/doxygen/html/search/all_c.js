var searchData=
[
  ['quantita_0',['quantita',['../structgadget.html#a4f740dac121865f893f6738fb7f5a786',1,'gadget::quantita()'],['../structordine.html#a4f740dac121865f893f6738fb7f5a786',1,'ordine::quantita()']]]
];
