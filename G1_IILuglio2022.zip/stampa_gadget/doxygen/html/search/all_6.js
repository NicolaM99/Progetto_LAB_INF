var searchData=
[
  ['id_0',['id',['../structordine.html#a7441ef0865bcb3db9b8064dd7375c1ea',1,'ordine']]],
  ['input_5ffloat_1',['input_float',['../funzioni_8c.html#a3622974e9814dd0e0a54e96e40dd7bc8',1,'input_float(const char *label):&#160;funzioni.c'],['../funzioni_8h.html#a3622974e9814dd0e0a54e96e40dd7bc8',1,'input_float(const char *label):&#160;funzioni.c']]],
  ['input_5fintero_2',['input_intero',['../funzioni_8c.html#a7a63613f35e5fd4d13323f82d54621fc',1,'input_intero(const char *label):&#160;funzioni.c'],['../funzioni_8h.html#a7a63613f35e5fd4d13323f82d54621fc',1,'input_intero(const char *label):&#160;funzioni.c']]]
];
