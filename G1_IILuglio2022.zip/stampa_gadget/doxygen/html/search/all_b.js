var searchData=
[
  ['password_0',['password',['../structvenditore.html#a853a9646b18a7702f2c3dc014286b8a7',1,'venditore::password()'],['../structcliente.html#a853a9646b18a7702f2c3dc014286b8a7',1,'cliente::password()']]],
  ['prezzo_1',['prezzo',['../structgadget.html#a0688ed2198a87310fc68d11719791b28',1,'gadget']]]
];
