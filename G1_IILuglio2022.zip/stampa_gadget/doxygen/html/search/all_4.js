var searchData=
[
  ['funzioni_2ec_0',['funzioni.c',['../funzioni_8c.html',1,'']]],
  ['funzioni_2eh_1',['funzioni.h',['../funzioni_8h.html',1,'']]]
];
