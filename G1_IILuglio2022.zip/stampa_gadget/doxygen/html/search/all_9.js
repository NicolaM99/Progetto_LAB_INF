var searchData=
[
  ['nome_0',['nome',['../structvenditore.html#a5cb5e5de1ecca56063c1adb29b239464',1,'venditore::nome()'],['../structcliente.html#a5cb5e5de1ecca56063c1adb29b239464',1,'cliente::nome()'],['../structgadget.html#a5cb5e5de1ecca56063c1adb29b239464',1,'gadget::nome()']]]
];
