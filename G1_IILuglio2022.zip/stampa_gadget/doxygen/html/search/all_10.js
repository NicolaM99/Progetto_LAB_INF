var searchData=
[
  ['userid_0',['userID',['../structvenditore.html#abea63f3849eac19ddbb789da6978cb60',1,'venditore::userID()'],['../structcliente.html#abea63f3849eac19ddbb789da6978cb60',1,'cliente::userID()']]],
  ['utente_5floggato_1',['utente_loggato',['../strutture_8h.html#afec952c79e299e91374a4e6d31e2ed2b',1,'strutture.h']]]
];
