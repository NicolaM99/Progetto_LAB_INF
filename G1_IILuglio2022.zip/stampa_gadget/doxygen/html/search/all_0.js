var searchData=
[
  ['accesso_5fcliente_0',['accesso_cliente',['../funzioni_8c.html#ad31da600aec7b08f30e265640edc9e3a',1,'accesso_cliente(FILE *fileClienti):&#160;funzioni.c'],['../funzioni_8h.html#ad31da600aec7b08f30e265640edc9e3a',1,'accesso_cliente(FILE *fileClienti):&#160;funzioni.c']]],
  ['accesso_5fvenditore_1',['accesso_venditore',['../funzioni_8c.html#af4b927d3a7939ed137e6cfafb9faff96',1,'accesso_venditore(FILE *fileVenditori):&#160;funzioni.c'],['../funzioni_8h.html#af4b927d3a7939ed137e6cfafb9faff96',1,'accesso_venditore(FILE *fileVenditori):&#160;funzioni.c']]],
  ['aggiungi_5fgadget_2',['aggiungi_gadget',['../funzioni_8c.html#aaa647797e488d8520489dca95e624985',1,'aggiungi_gadget(FILE *fileVenditori, FILE *fileGadget):&#160;funzioni.c'],['../funzioni_8h.html#aaa647797e488d8520489dca95e624985',1,'aggiungi_gadget(FILE *fileVenditori, FILE *fileGadget):&#160;funzioni.c']]]
];
