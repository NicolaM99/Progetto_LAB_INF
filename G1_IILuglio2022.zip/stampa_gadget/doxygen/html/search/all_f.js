var searchData=
[
  ['tipologia_0',['tipologia',['../structgadget.html#a11532a146b6c09dfc9793276f63b6173',1,'gadget']]]
];
