var searchData=
[
  ['venduti_0',['venduti',['../structgadget.html#a951697a93638873e83391de915eaed76',1,'gadget']]]
];
