var searchData=
[
  ['max_0',['MAX',['../strutture_8h.html#a392fb874e547e582e9c66a08a1f23326',1,'strutture.h']]]
];
