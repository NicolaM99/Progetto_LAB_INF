var searchData=
[
  ['eliminato_0',['eliminato',['../structgadget.html#ac7f8bc8482afe78ec4788b0974774003',1,'gadget']]],
  ['evaso_1',['evaso',['../structordine.html#ab25b8db148db306202e3ed41aefe082c',1,'ordine']]]
];
