/**
 * _______________________________________________________________________________
 *|@file       : strutture.h                       	                              |
 *| File di intestazione delle strutture										  |
 *|@authors    : Gruppo 1 - Emanuele Russo, 735806 - Nicola Mastromarino, 757709  |
 *|@date 27/05/2022																  |
 *|@version 0.1																	  |
 *|_______________________________________________________________________________|
 */

#ifndef STRUTTURE_H
#define STRUTTURE_H

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/**
 * Contiene il codice dell'utente loggato
 * @warning � una variabile di sessione
 */
int utente_loggato = -1;

/**
 * Massima lunghezza delle stringhe
 */
#define MAX 100

/**
 * @struct venditore
 * @brief Rappresentazione delle informazioni di un venditore
 */
typedef struct {
	int userID; // codice univoco e numerico
	char password[MAX];
	char cognome[MAX];
	char nome[MAX];
} venditore;

/**
 * @struct cliente
 * @brief Rappresentazione delle informazioni di un cliente
 */
typedef struct {
	int userID; // codice univoco e numerico
	char password[MAX];
	char sede[MAX]; // sede azienda
	char nome[MAX];
} cliente;

/**
 * @struct gadget
 * @brief Rappresentazione delle informazioni di un gadget
 */
typedef struct {
	int codice;
	char tipologia[MAX];
	char nome[MAX];
	char colore[MAX];
	char descrizione[MAX];
	float prezzo;
	int quantita;
	int venduti;
	int eliminato;
} gadget;

/**
 * @struct ordine
 * @brief Rappresentazione delle informazioni di un ordine
 */
typedef struct {
	int id;
	int codice_cliente;
	int codice_gadget;
	int quantita;
	float costo;
	char evaso[MAX];
	char commento[MAX];
} ordine;
#endif
