/**
 * _______________________________________________________________________________
 *|@file       : funzioni.h                       	                              |
 *| File di intestazione delle strutture										  |
 *|@authors    : Gruppo 1 - Emanuele Russo, 735806 - Nicola Mastromarino, 757709  |
 *|@date 27/05/2022																  |
 *|@version 0.1																	  |
 *|_______________________________________________________________________________|
 */

#ifndef FUNZIONI_H
#define FUNZIONI_H

#include <stdio.h>

//dichiarazione costante globale per la lunghezza delle stringhe nelle struct
#define LUNGHEZZA_CHAR_STRUCT 30

/**
 * Controlla l'input degli interi
 */
int controlla_intero(char *stringa);

/**
 * Controlla l'input dei float
 */
int controlla_float(char *stringa);

/**
 * Registrazione Cliente
 * @param fileClienti puntatore al file clienti.bin
 */
void registra_cliente(FILE *fileClienti);

/**
 * Acquisizione numero reale
 * @param label messaggio di input
 * @return numero reale
 */
float input_float(const char *label);

/**
 * Acquisizione numero intero naturale
 * @param label messaggio di input
 * @return numero intero
 */
int input_intero(const char *label);

/**
 * Registrazione Venditore
 * @param fileVenditori puntatore al file venditori.bin
 */
void registra_venditore(FILE *fileVenditori);

/**
 * Visualizzazione clienti
 * @param fileClienti puntatore al file clienti.bin
 */
void visualizza_cliente(FILE *fileClienti);

/**
 * Controlla, in fase di registrazione, l'univocit� dello userID del cliente
 * @param file puntatore al file clienti.bin
 * @param userID codice user inserito dall'utente in fase di registrazione
 * @return codice di controllo: 1 se lo userID � gi� esistente, 0 se � utilizzabile
 */
int controlla_cliente(FILE *file, int userID);

/**
 * Controlla, in fase di registrazione, l'univocit� dello userID del venditore
 * @param file puntatore al file venditori.bin
 * @param userID codice user inserito dall'utente in fase di registrazione
 * @return codice di controllo: 1 se lo userID � gi� esistente, 0 se � utilizzabile
 */
int controlla_venditore(FILE *file, int userID);

/**
 * Accesso venditore
 * @param fileVenditori puntatore al file vendutori.bin
 */
void chiusura_programma();

/**
 * Accesso venditore
 * @param fileVenditori puntatore al file vendutori.bin
 */
void accesso_cliente(FILE *fileClienti);

/**
 * Accesso venditore
 * @param fileVenditori puntatore al file vendutori.bin
 */
void accesso_venditore(FILE *fileVenditori);

/**
 * Aggiunta gadget al file
 * @param fileVenditori puntatore al file venditori.bin
 * @param fileGadget puntatore al file gadget.bin
 */
void aggiungi_gadget(FILE *fileVenditori, FILE *fileGadget);

/**
 * Modifica gadget
 * @param fileVenditori puntatore al file venditori.bin
 * @param fileGadget puntatore al file gadget.bin
 */
void modifica_gadget(FILE *fileVenditori, FILE *fileGadget);

/**
 * Visualizzazione elenco gadget
 * @param fileGadget puntatore al file gadget.bin
 * @return numero di gadget presenti nel file
 */
int visualizza_gadget(FILE *fileGadget);

/**
 * Aggiunta nuovo ordine nel file
 * @param fileClienti puntatore al file clienti.bin
 * @param fileOrdini puntatore al file ordini.bin
 * @param fileGadget puntatore al file gadget.bin
 */
void effettua_ordine(FILE *fileClienti, FILE *fileOrdini, FILE *fileGadget);

/**
 * Eliminazione gadget dal file
 * @param fileGadget puntatore al file gadget.bin
 * @return puntatore al NUOVO file gadget.bin
 */
FILE* elimina_gadget(FILE *fileGadget);

/**
 * Visualizzazione ordini del cliente
 * @param fileOrdini puntatore al file ordini.bin
 * @param fileGadget puntatore al file gadget.bin
 */
void visualizza_i_tuoi_ordini(FILE *fileOrdini, FILE *fileGadget);

/**
 * Ricerca gadget nel file
 * @param fileGadget puntatore al file gadget.bin
 * @param nome_gadget nome gadget inserito dall'utente
 * @param codice codice gadget da ricercare
 * @return variabile di controllo della presenza del gadget (perch� potrebbe essere stato eliminato da un venditore)
 */
int ricerca_gadget(FILE *fileGadget, char nome_gadget[], int codice);

/**
 * Visualizzazione di tutti gli ordini effettuati da tutti i clienti
 * @param fileOrdini puntatore al file ordini.bin
 */
void storico_ordini(FILE *fileOrdini);

/**
 * Visualizzazione gadget pi� venduti
 * @param fileGadget puntatore al file gadget.bin
 */
void statistiche_gadget(FILE *fileGadget);

/**
 * Ordinamento vettore
 * @param tabella vettore dei pezzi venduti
 * @param inizio indice del vettore che parte dal primo elemento
 * @param fine indice del vettore che parte dall'ultimo elemento
 */
void merge_sort(int tabella[], int inizio, int fine);

/**
 * Unione dei due sottovettori ordinati
 * @param tabella vettore dei pezzi venduti
 * @param inizio indice del vettore che punta al primo elemento
 * @param medio indice del vettore che punta all'elemento centrale
 * @param fine indice del vettore che punta all'ultimo elemento
 */
void merge(int tabella[], int inizio, int medio, int fine);

/**
 * Modifica dati cliente
 * @param fileClienti puntatore al file clienti.bin
 */
void modifica_cliente(FILE *fileClienti);

/**
 * Eliminazione account cliente dal file
 * @param fileClienti puntatore al file clienti.bin
 * @return puntatore al NUOVO file clienti.bin
 */
FILE* elimina_cliente(FILE *fileClienti);

#endif
