/**
 * _______________________________________________________________________________
 *|@file       : gadget.c                       	                              |
 *| File di intestazione delle strutture										  |
 *|@authors    : Gruppo 1 - Emanuele Russo, 735806 - Nicola Mastromarino, 757709  |
 *|@date 27/05/2022																  |
 *|@version 0.1																	  |
 *|_______________________________________________________________________________|
 */

#include "menu.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Funzione principale con dichiarazione file e chiamata della funzione del menu principale.
 * @return 0
 */
int main() {
	//Dichiarazione puntatori
	FILE *fileVenditori = NULL;
	FILE *fileClienti = NULL;
	FILE *fileGadget = NULL;
	FILE *fileOrdini = NULL;

	setvbuf(stdout, NULL, _IONBF, 0);

	menu_principale(fileClienti, fileVenditori, fileGadget, fileOrdini);

	printf("\n\nCHIUSURA PROGRAMMA...\n\nPROGRAMMA TERMINATO.");

	return 0;
}
