/**
 * _______________________________________________________________________________
 *|@file       : funzioni.c                       	                              |
 *| File di intestazione delle strutture										  |
 *|@authors    : Gruppo 1 - Emanuele Russo, 735806 - Nicola Mastromarino, 757709  |
 *|@date 27/05/2022																  |
 *|@version 0.1																	  |
 *|_______________________________________________________________________________|
 */

#include "funzioni.h"
#include "strutture.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Controlla l'input degli interi
 * @param stringa inserita dall'utente
 * @return variabile di controllo: 0 = non intero, 1 = intero
 */
int controlla_intero(char *stringa) {
	char c;
	int i = 0;
	int controllo = 1;
	while (((c = stringa[i]) != '\0') && (controllo != 0)) {
		if (!isdigit(c))
			controllo = 0;
		i++;
	}
	return controllo;
}

/**
 * Controlla l'input dei reali
 * @param stringa inserita dall'utente
 * @return variabile di controllo: 0 = non reale, 1 = reale.
 */
int controlla_float(char *stringa) {
	char c;
	int i = 0;
	int controllo = 1;
	int controllo_punto = 0;
	while (((c = stringa[i++]) != '\0') && (controllo != 0)) {
		if ((!isdigit(c)) && (c != '.'))
			controllo = 0;
		else if (controllo_punto == 0) {
			if (c == '.')
				controllo_punto = 1;
		} else if (c == '.')
			controllo = 0;
	}
	return controllo;
}

/**
 * Acquisizione numero intero naturale
 * @param label messaggio di input
 * @return numero intero
 */
int input_intero(const char *label) {
	char input[MAX];
	int numero;
	do {
		printf("%s", label);
		scanf("%s", input);
	} while (!controlla_intero(input));
	numero = atoi(input);
	return numero;
}

/**
 * Acquisizione numero reale
 * @param label messaggio di input
 * @return numero reale
 */
float input_float(const char *label) {
	char input[MAX];
	float numero;
	do {
		printf("%s", label);
		scanf("%s", input);
	} while (!controlla_float(input));
	numero = atof(input);
	return numero;
}

/**
 * Registrazione Cliente
 * @param fileClienti puntatore al file clienti.bin
 */
void registra_cliente(FILE *fileClienti) {
	cliente utente = { 0, "", "", "" };
	int userID = -1;  // Variabile contenente il codice inserito dall'utente
	int controllo; // Variabile di lavoro per controlli

	fileClienti = fopen("clienti.bin", "rb+");
	if (fileClienti == NULL) {
		printf("Impossibile aprire file clienti\n");
	} else {
		do {
			userID = input_intero("Inserire uno User ID identificativo numerico: ");
			controllo = controlla_cliente(fileClienti, userID);
		} while (controllo == 1);

		// inserimento dati clienti
		setvbuf(stdout, NULL, _IONBF, 0);
		printf("Password cliente: ");
		scanf("%s", utente.password);
		setvbuf(stdin, NULL, _IONBF, 0);
		printf("Nome azienda: ");
		gets(utente.nome);
		printf("Sede azienda: ");
		gets(utente.sede);
		utente.userID = userID;

		fseek(fileClienti, 0, SEEK_END); //posiziono il puntatore alla fine del file
		fwrite(&utente, sizeof(cliente), 1, fileClienti); // scrittura record sul file

		printf("\n\nRegistrazione azienda '%s' correttamente effettuata\n",
				utente.nome);
		if (fclose(fileClienti) != 0)
			printf("Errore in chiusura file.\n");
	}
}

/**
 * Registrazione Venditore
 * @param fileVenditori puntatore al file venditori.bin
 */
void registra_venditore(FILE *fileVenditori) {
	venditore utente = { 0, "", "", "" };
	int userID;  // Variabile contenente il codice inserito dall'utente
	int controllo; // Variabile di lavoro per controlli

	fileVenditori = fopen("venditori.bin", "rb+");
	if (fileVenditori == NULL) {
		printf("Impossibile aprire file venditori\n");
	} else {
		printf("Inserire i tuoi dati di venditore \n");
		do {
			userID = input_intero(
					"Inserire uno User ID identificativo numerico:");
			controllo = controlla_venditore(fileVenditori, userID);
		} while (controllo == 1);

		// inserimento dati venditori
		printf("Password venditore: ");
		scanf("%s", utente.password);
		setvbuf(stdin, NULL, _IONBF, 0);
		printf("Nome venditore: ");
		gets(utente.nome);
		printf("Cognome venditore: ");
		gets(utente.cognome);
		utente.userID = userID;

		fseek(fileVenditori, 0, SEEK_END);
		fwrite(&utente, sizeof(venditore), 1, fileVenditori); // scrittura struct sul file

		printf("*Inserimento Terminato*\n");

		printf("\n\n\nRegistrazione di %s %s correttamente effettuata\n",
				utente.nome, utente.cognome);
		if (fclose(fileVenditori) != 0)
			printf("Errore in chiusura file.\n");
	}
}

/**
 * Visualizzazione clienti
 * @param fileClienti puntatore al file clienti.bin
 */
void visualizza_cliente(FILE *fileClienti) {
	cliente utente = { 0, "", "", "" };
	rewind(fileClienti);
	if (getc(fileClienti) != EOF) {		//controllo che il file non sia vuoto
		rewind(fileClienti);
		fread(&utente, sizeof(cliente), 1, fileClienti);

		printf("\n\nEcco l'elenco di tutte le aziende registrate\n\n");
		printf(" %-25s %-20s %-20s\n\n", "Nome azienda", "User ID", "Sede");

		while (!feof(fileClienti)) {

			printf(" %-25s %-20d %-20s\n\n", utente.nome, utente.userID,
					utente.sede);

			fread(&utente, sizeof(cliente), 1, fileClienti);
		}
	} else
		printf("Nessuna azienda registrata\n");
}

/**
 * Controlla, in fase di registrazione, l'univocità dello userID del venditore
 * @param file puntatore al file venditori.bin
 * @param userID codice user inserito dall'utente in fase di registrazione
 * @return codice di controllo: 1 se lo userID è già esistente, 0 se è utilizzabile
 */
int controlla_venditore(FILE *file, int userID) {
	venditore utente;
	int controllo = 0;
	rewind(file);
	if (getc(file) != EOF) {		//controllo che il file non sia vuoto
		rewind(file);
		while (!feof(file)) // ciclo fino a fine file, per controllare l'univocità
		// del codice identificativo del creatore
		{
			fread(&utente, sizeof(venditore), 1, file); // lettura struct dal file

			if (userID == utente.userID) { // controllo corrispondenza codici
				controllo = 1;
			}
		}
	}
	if (controllo == 1) {
		printf("User ID gia' in utilizzo \n"); // messaggio di errore in caso di
		// codice già in utlizzo
	}
	return controllo;
}

/**
 * Controlla, in fase di registrazione, l'univocità dello userID del cliente
 * @param file puntatore al file clienti.bin
 * @param userID codice user inserito dall'utente in fase di registrazione
 * @return codice di controllo: 1 se lo userID è già esistente, 0 se è utilizzabile
 */
int controlla_cliente(FILE *file, int userID) {
	cliente utente;
	int controllo = 0;
	rewind(file);
	if (getc(file) != EOF) {		//controllo che il file non sia vuoto
		rewind(file);
		while (!feof(file)) // ciclo fino a fine file, per controllare l'univocità
		// del codice identificativo del creatore
		{
			fread(&utente, sizeof(cliente), 1, file); // lettura struct dal file

			if (userID == utente.userID) { // controllo corrispondenza codici
				controllo = 1;
			}
		}
	}
	if (controllo == 1) {
		printf("User ID gia' in utilizzo \n"); // messaggio di errore in caso di
		// codice già  in utlizzo
	}
	return controllo;
}

/**
 * Chiusura del programma
 */
void chiusura_programma() {
	printf("\n\nCHIUSURA PROGRAMMA...\n\nPROGRAMMA TERMINATO");
	exit(EXIT_SUCCESS);
}

/**
 * Accesso venditore
 * @param fileVenditori puntatore al file vendutori.bin
 */
void accesso_venditore(FILE *fileVenditori) {
	int userID = 0; //userID da cercare per il login
	char password[MAX];
	int trovato = 0; //variabile utile a capire se lo userID esiste o meno
	int match = 0;
	venditore utente = { 0, "", "", "" };
	do {

		userID = input_intero("Inserire il tuo UserID: ");
		rewind(fileVenditori);
		fread(&utente, sizeof(venditore), 1, fileVenditori);
		while ((!feof(fileVenditori)) && (trovato == 0)) {
			if (utente.userID == userID)
				trovato = 1;
			else
				fread(&utente, sizeof(venditore), 1, fileVenditori);
		}
		if (trovato == 0)
			printf("User ID non trovato, prego riprovare\n");
	} while (trovato == 0);
	printf("Inserire password: ");
	do {
		scanf("%s", password);
		if (strcmp(utente.password, password) == 0)
			match = 1;
		else
			printf("Password errata, prego riprovare: ");
	} while (match == 0);
	printf("\n\n\nBenvenuto/a %s %s\n", utente.nome, utente.cognome);

}

/**
 * Accesso clienti
 * @param fileClienti puntatore al file clienti.bin
 */
void accesso_cliente(FILE *fileClienti) {
	int userID = 0; //user da cercare per il login
	char password[MAX];
	int trovato = 0; //variabile utile a capire se lo user esiste o meno
	int match = 0;
	cliente utente = { 0, "", "", "" };

	do {
		userID = input_intero("Inserire il tuo User ID: ");
		rewind(fileClienti);
		fread(&utente, sizeof(cliente), 1, fileClienti);
		//finchè non finisce il file oopure finchè lo userID non è stato trovato, confronta lo userID
		//inserito con quello letto dal file e se non corrisponde, legge un altro record e cosi via.
		while ((!feof(fileClienti)) && (trovato == 0)) {
			if (utente.userID == userID) {
				trovato = 1;
				utente_loggato = userID;
			} else
				fread(&utente, sizeof(cliente), 1, fileClienti);
		}
		if (trovato == 0)
			printf("User ID non trovato, prego riprovare\n");
	} while (trovato == 0);
	printf("Inserire password: ");
	do {
		scanf("%s", password);
		if (strcmp(utente.password, password) == 0)
			match = 1;
		else
			printf("Password errata, prego riprovare: ");
	} while (match == 0);

	printf("\n\n\nLogin azienda %s correttamente effettuato\n", utente.nome);

}

/**
 * Aggiunta gadget al file
 * @param fileVenditori puntatore al file venditori.bin
 * @param fileGadget puntatore al file gadget.bin
 */
void aggiungi_gadget(FILE *fileVenditori, FILE *fileGadget) {
	gadget pezzo = { 0, "", "", "", "", 0.0, 0, 0, 0 };
	int controllo; // Variabile di lavoro per controlli
	int indice;    // indice ciclo for
	char *Tipologie[LUNGHEZZA_CHAR_STRUCT] = { "Maglia", "Tazza", "Cappello",
			"Penna", "Portachiavi", "Borraccia", "Altro" }; // array di stringhe per le risposte consentite

	fseek(fileGadget, -1 * sizeof(gadget), SEEK_END);
	fread(&pezzo, sizeof(gadget), 1, fileGadget);
	// lettura ultimo record dal file e incremento campo codice che sarà il codice del gadget da inserire
	pezzo.codice++;
	printf("Inserimento dati Gadget num.ro %d: \n", pezzo.codice);

	// inserimento dati gadget
	pezzo.eliminato = 0;
	pezzo.venduti = 0;
	setvbuf(stdin, NULL, _IONBF, 0);
	printf("Nome Gadget: ");
	gets(pezzo.nome);
	printf("Colore Gadget: ");
	gets(pezzo.colore);
	setvbuf(stdin, NULL, _IONBF, 0);
	printf("Descrizione Gadget: ");
	scanf("%100[^\n]", pezzo.descrizione); //leggo tutti i caratteri inseriti (max 100) fino al carattere \n
	pezzo.prezzo = input_float("Prezzo Gadget: ");
	pezzo.quantita = input_intero("Quantita' gadget: ");
	do {
		controllo = 0;
		printf("Tipologia Gadget (Sceglila tra: Maglia, Tazza, Cappello, Penna, Portachiavi, Borraccia, Altro): ");
		fflush(stdin);
		gets(pezzo.tipologia);
		for (int i = 1; i < LUNGHEZZA_CHAR_STRUCT; i++)
			pezzo.tipologia[i] = tolower(pezzo.tipologia[i]);
		pezzo.tipologia[0] = toupper(pezzo.tipologia[0]);
		// trasformo la prima lettera della risposta utente in maiuscolo e le altre in minuscolo cosi posso confrontarla
		//con le tipologie standard

		for (indice = 0; indice < 7; indice++) {
			if (strcmp(pezzo.tipologia, Tipologie[indice]) == 0) { // controllo se l'utente abbia scelto una parola
				// dall'elenco
				controllo = 1;
			}
		}
		if (controllo != 1) {
			printf("Ritenta inserimento \n"); // messaggio di errore in caso di
			// codice già in utlizzo
		}
	} while (controllo != 1);

	fseek(fileGadget, 0, SEEK_END);
	//Posiziono  il puntatore alla fine del file
	fwrite(&pezzo, sizeof(gadget), 1, fileGadget); // scrittura struct sul file

	printf("*Inserimento Terminato*\n");
}

/**
 * Modifica gadget
 * @param fileVenditori puntatore al file venditori.bin
 * @param fileGadget puntatore al file gadget.bin
 */
void modifica_gadget(FILE *fileVenditori, FILE *fileGadget) {
	gadget pezzo, copia = { 0, "", "", "", "", 0.0, 0, 0, 0 };
	char *Tipologie[LUNGHEZZA_CHAR_STRUCT] = { "Maglia", "Tazza", "Cappello",
			"Penna", "Portachiavi", "Borraccia", "Altro" }; // array di stringhe per le risposte delle tipologie consentite
	int codice;    // Variabile contenente il codice inserito dall'utente
	int indice;    // indice ciclo for
	int trovato, controllo;
	visualizza_gadget(fileGadget);
	do {
		codice = input_intero("Inserire il codice identificativo numerico del gadget che si vuole modificare: ");
		rewind(fileGadget);
		trovato = 0;

		while ((!feof(fileGadget)) && (trovato == 0)) {
			fread(&pezzo, sizeof(gadget), 1, fileGadget); // lettura record dal file
			if (pezzo.codice == codice) {
				trovato = 1;
				fseek(fileGadget, -1 * sizeof(gadget), SEEK_CUR);
				//mi posiziono indietro di un record (per tornare a quello attualmente preso in considerazione)
				//e successivamente leggo record di copia per mantenere i campi non modificabili dall'utente
				fread(&copia, sizeof(gadget), 1, fileGadget);
				// Inserimento nuovi dati
				setvbuf(stdin, NULL, _IONBF, 0);
				printf("\n\nInserire nuovi dati\n\n");
				printf("Nome gadget: ");
				gets(pezzo.nome);
				do {
					controllo = 0;
					printf("Tipologia (Sceglila tra: Maglia, Tazza, Cappello, Penna, Portachiavi, Borraccia, Altro): ");
					gets(pezzo.tipologia);
					for (int i = 1; i < LUNGHEZZA_CHAR_STRUCT; i++)
						pezzo.tipologia[i] = tolower(pezzo.tipologia[i]);
					pezzo.tipologia[0] = toupper(pezzo.tipologia[0]);
					// trasformo la prima lettera della risposta utente in maiuscolo e le altre in minuscolo
					for (indice = 0; indice < 7; indice++) {
						if (strcmp(pezzo.tipologia, Tipologie[indice]) == 0) {
							// controllo se l'utente abbia scelto una parola presente nell'elenco
							controllo = 1;
						}
					}
					if (controllo != 1) {
						printf("Ritenta inserimento, tipologia non presente \n"); // messaggio di errore
					}
				} while (controllo != 1);

				printf("Colore gadget: ");
				gets(pezzo.colore);
				printf("Descrizione: ");
				gets(pezzo.descrizione);
				pezzo.prezzo = input_float("Prezzo: ");
				pezzo.quantita = input_intero("Quantita' disponibile: ");
				pezzo.venduti = copia.venduti;
				pezzo.codice = copia.codice;

				fseek(fileGadget, -1 * sizeof(gadget), SEEK_CUR);
				//mi posiziono sul record da modificare e scrivo il record aggiornato
				fwrite(&pezzo, sizeof(gadget), 1, fileGadget); // sovrascrittura struct sul file
				printf("***Gadget correttamente modificato***\n");
				printf("\nVisualizzazione tabella aggiornata\n");
				visualizza_gadget(fileGadget);
			}
		}

	} while (trovato == 0);
}

/**
 * Visualizzazione elenco gadget
 * @param fileGadget puntatore al file gadget.bin
 * @return numero di gadget presenti nel file
 */
int visualizza_gadget(FILE *fileGadget) {
	gadget pezzo = { 0, "", "", "", "", 0.0, 0, 0, 0 };
	int numero_gadget = 0;
	rewind(fileGadget);
	if (fgetc(fileGadget) == EOF) {	//controllo che il file non sia vuoto
		printf("Nessun gadget trovato\n");
		numero_gadget = 0;
	} else {
		rewind(fileGadget);
		printf(" %-10s %-30s %-40s %-15s %-15s %-10s %-10s\n\n", "Codice",
				"Nome", "Descrizione", "Colore", "Tipologia", "Prezzo",
				"Quantita' disponibile");
		while (!feof(fileGadget)) {
			fread(&pezzo, sizeof(gadget), 1, fileGadget);
			numero_gadget++;//leggo dal file un record alla volta, lo visualizzo e incremento il numero di gadget
			printf(" %-10d %-30s %-40s %-15s %-15s %-10.2f %-10d\n\n",
					pezzo.codice, pezzo.nome, pezzo.descrizione, pezzo.colore,
					pezzo.tipologia, pezzo.prezzo, pezzo.quantita);
			if (fgetc(fileGadget) != EOF) { /*controllo che il file non sia vuoto perchè la funzione feof() setta il suo valore
			 a true quando viene preso EOF, se non controllassi qui, con il while verrebbe preso
			 un altro record contenente EOF e verrebbe visualizzato due volte l'ultimo.
			 Invece prendendo un singolo carattere con fgetc() la funzione feof() assume valore
			 true e dunque grazie alla condizione del while, il ciclo termina.
			 */
				fseek(fileGadget, -1, SEEK_CUR);
			}
		}
	}
	rewind(fileGadget);
	return numero_gadget;
}

/**
 * Eliminazione gadget dal file
 * @param fileGadget puntatore al file gadget.bin
 * @return puntatore al NUOVO file gadget.bin
 */
FILE* elimina_gadget(FILE *fileGadget) {
	gadget pezzo = { 0, "", "", "", "", 0.0, 0, 0, 0 };
	int codice;    // Variabile contenente il codice inserito dall'utente
	int controllo; // Variabile di lavoro per controlli
	int indice_file_obsoleto, indice_nuovo_file;
	FILE *aggiorna;

	visualizza_gadget(fileGadget);
	do {
		codice = input_intero("Inserire il codice identificativo del gadget che si vuole eliminare: \n");
		controllo = 0;

		rewind(fileGadget);
		if (fgetc(fileGadget) == EOF) { //controllo che il file non sia vuoto
			printf("Nessun gadget inserito\n");
		} else {
			rewind(fileGadget);
			while ((!feof(fileGadget)) && (controllo == 0)) { //ciclo finchè il pezzo non è stato trovato e
															  // ci sono ancora elementi da controllare
				fread(&pezzo, sizeof(gadget), 1, fileGadget); // lettura record dal file
				if (pezzo.codice == codice) {
					controllo = 1;
					pezzo.eliminato = 1;
					fseek(fileGadget, -1 * sizeof(gadget), SEEK_CUR);
					fwrite(&pezzo, sizeof(gadget), 1, fileGadget);
					indice_file_obsoleto = 0;
					indice_nuovo_file = 0;
					aggiorna = fopen("aggiornati.bin", "wb+"); //apertura (e creazione) di un nuovo file contenente
															   // tutti i gadget non eliminati
					if (aggiorna == NULL)
						printf("Errore in apertura file.\n");
					else {
						/* Finchè ci sono ancora gadget da posizionare nel nuovo file,
						 posiziono il puntatore al file gadget.bin facendolo puntare al prossimo
						 gadget da controllare, successivamente esso legge un record e viene
						 effettuato un controllo sul campo eliminato.
						 Se questo è zero, allora si posiziona il puntatore
						 al file aggiornati.bin in modo che esso punti alla fine dell'ultimo record inserito.
						 Dopo si inserisce il gadget nel nuovo file e
						 si incrementa il numero di record inseriti in quest'ultimo.
						 Se invece il campo eliminato è uguale ad uno allora si incrementa solo il numero di
						 gadget già controllati.
						 */
						while (!feof(fileGadget)) {
							fseek(fileGadget,
									indice_file_obsoleto * sizeof(gadget),
									SEEK_SET);
							fread(&pezzo, sizeof(gadget), 1, fileGadget);

							if ((pezzo.eliminato == 0) && (!feof(fileGadget))) {
								fseek(aggiorna,
										indice_nuovo_file * sizeof(gadget),
										SEEK_SET);
								fwrite(&pezzo, sizeof(gadget), 1, aggiorna);
								indice_file_obsoleto++;
								indice_nuovo_file++;
							} else if ((pezzo.eliminato == 1)
									&& (!feof(fileGadget))) {
								indice_file_obsoleto++;
							}
							if (fgetc(fileGadget) != EOF) {/*controllo che il file non sia vuoto perchè la funzione feof() setta il suo valore
							 a true quando viene preso EOF, se non controllassi qui, con il while verrebbe preso
							 un altro record contenente EOF.
							 Invece prendendo un singolo carattere con fgetc() la funzione feof() assume valore
							 true e dunque grazie alla condizione del while, il ciclo termina.*/
								fseek(fileGadget, -1, SEEK_CUR);
							}
						}

						if ((fclose(aggiorna) != 0)
								|| (fclose(fileGadget) != 0))
							printf("Errore in chiusura file.\n");
						remove("gadget.bin");//rimozione file gadget.bin, ormai obsoleto
						rename("aggiornati.bin", "gadget.bin"); //rinominazione file aggiornato in gadget.bin
						fileGadget = aggiorna; //passaggio tra puntatori, in questo modo fileGadget punta
											   //al nuovo file, ormai denominato con gadget.bin
						fileGadget = fopen("gadget.bin", "rb+");
						if (fileGadget == NULL) {
							printf("Impossibile aprire file.\n");
						} else {
							printf("***Gadget correttamente eliminato***\n");
							printf("\nVisualizzazione tabella aggiornata:\n");
							visualizza_gadget(fileGadget);
						}
					}
				}
			}
			if (controllo == 0)
				printf("Campo vuoto, riprova \n"); // messaggio di errore
		}
	} while (controllo == 0); // se record è pieno
	return fileGadget;
}

/**
 * Aggiunta nuovo ordine nel file
 * @param fileClienti puntatore al file clienti.bin
 * @param fileOrdini puntatore al file ordini.bin
 * @param fileGadget puntatore al file gadget.bin
 */
void effettua_ordine(FILE *fileClienti, FILE *fileOrdini, FILE *fileGadget) {
	char prodotto[MAX];
	char parole[20][MAX];
	const char DELIMITATORE[2] = " ";
	gadget pezzo = { 0, "", "", "", "", 0.0, 0, 0, 0 };
	gadget oggetto = { 0, "", "", "", "", 0.0, 0, 0, 0 };
	ordine nuovo = { 0, 0, 0, 0, 0.0, "", "" };
	int i, aggiungi, dimensione, trovato, codice;
	char *token;
	FILE *gadgetRistretto;

	rewind(fileGadget);
	setvbuf(stdin, NULL, _IONBF, 0);
	printf("Inserire nome gadget che si vuole acquistare\n");
	scanf("%100[^\n]", prodotto); //acquisisco come stringa max 100 caratteri, e leggo tutti i caratteri fino al \n
	gadgetRistretto = fopen("gadget_ricerca.bin", "wb+");
	if (gadgetRistretto == NULL)
		printf("Errore in apertura file.\n");
	else {
		token = strtok(prodotto, DELIMITATORE);
		i = 0;
		while (token != NULL) {
			strcpy(parole[i++], token);
			token = strtok(NULL, DELIMITATORE);
		}
		dimensione = i;
		if (fgetc(fileGadget) == EOF) {
			printf("Nessun gadget trovato\n");
		} else
			rewind(fileGadget);
		while (!feof(fileGadget)) {
			fread(&pezzo, sizeof(gadget), 1, fileGadget);
			aggiungi = 1;
			for (i = 0; i < dimensione; i++) {
				if (strstr(pezzo.nome, parole[i]) == NULL) {
					aggiungi = 0;

				}

			}
			if (aggiungi == 1) {
				fwrite(&pezzo, sizeof(gadget), 1, gadgetRistretto);
			}
			if (fgetc(fileGadget) != EOF) {
				fseek(fileGadget, -1, SEEK_CUR);
			}

		}
		if (visualizza_gadget(gadgetRistretto) != 0) {
			trovato = 0;
			do {
				rewind(gadgetRistretto);
				codice = input_intero("Inserire il codice identificativo del gadget che si vuole acquistare: \n");
				while ((!feof(gadgetRistretto)) && (trovato == 0)) {
					fread(&pezzo, sizeof(gadget), 1, gadgetRistretto); // lettura record dal file
					if (pezzo.codice == codice)
						trovato = 1;
				}
				if (trovato == 0) {
					printf("Codice non presente, prego ritentare.");
				}
			} while (trovato == 0);
			fseek(fileOrdini, -1 * sizeof(ordine), SEEK_END);
			fread(&nuovo, sizeof(ordine), 1, fileOrdini);
			nuovo.id++;
			nuovo.quantita = input_intero("Inserire numero pezzi desiderati:  ");
			fflush(stdin);
			printf("Inserisci un commento:  ");
			scanf("%100[^\n]", nuovo.commento);
			nuovo.costo = pezzo.prezzo * nuovo.quantita;
			if (pezzo.quantita < nuovo.quantita) {
				strcpy(nuovo.evaso, "NON EVASO");
				printf("\n\n***Ordine non evadibile subito, quindi in attesa di approvazione.***\n");
			} else {
				strcpy(nuovo.evaso, "EVASO");
				printf("\n\n*** Ordine correttamente eseguito. Il costo totale di quanto acquistato e' di euro %.2f ***\n",
						nuovo.costo);
				pezzo.quantita -= nuovo.quantita;
				pezzo.venduti += nuovo.quantita;
				rewind(fileGadget);
				trovato = 0;
				while ((!feof(fileGadget)) && (trovato == 0)) {
					fread(&oggetto, sizeof(gadget), 1, fileGadget);
					if (oggetto.codice == pezzo.codice) {

						fseek(fileGadget, -1 * sizeof(gadget), SEEK_CUR);
						fwrite(&pezzo, sizeof(gadget), 1, fileGadget);
						trovato = 1;
					}
				}

			}
			nuovo.codice_cliente = utente_loggato;
			nuovo.codice_gadget = pezzo.codice;
			fseek(fileOrdini, 0, SEEK_END);
			fwrite(&nuovo, sizeof(ordine), 1, fileOrdini);
			if (fclose(gadgetRistretto) != 0)
				printf("Errore in chiusura file.\n");
			remove("gadget_ricerca.bin");
		}
	}
}

/**
 * Visualizzazione ordini del cliente
 * @param fileOrdini puntatore al file ordini.bin
 * @param fileGadget puntatore al file gadget.bin
 */
void visualizza_i_tuoi_ordini(FILE *fileOrdini, FILE *fileGadget) {
	ordine acquisto = { 0, 0, 0, 0, 0.0, "", "" };
	int controllo = 0;
	int trovato = 0;
	int comodo = 0;
	char nome[MAX];
	rewind(fileOrdini);

	while (!feof(fileOrdini)) {
		fread(&acquisto, sizeof(ordine), 1, fileOrdini);
		if (acquisto.codice_cliente == utente_loggato) {
			controllo = 1;
		}
	}

	rewind(fileOrdini);
	if (controllo == 1) {
		printf("Ecco gli ordini da te effettuati:\n");
		printf("%-10s %-20s %-10s %-25s %-30s\n\n", "ID ordine", "Nome Gadget",
				"Ordine", "Costo totale in Euro", "Commento");
		if (fgetc(fileOrdini) == EOF) {
			printf("File ordini vuoto\n");
		} else {
			rewind(fileOrdini);
			while (!feof(fileOrdini)) {
				fread(&acquisto, sizeof(ordine), 1, fileOrdini);
				if (acquisto.codice_cliente == utente_loggato) {
					trovato = ricerca_gadget(fileGadget, nome,
							acquisto.codice_gadget);
					if (trovato != 0)
						printf("%-10d %-20s %-10s %-25.2f %-30s\n\n",
								acquisto.id, nome, acquisto.evaso,
								acquisto.costo, acquisto.commento);
					else
						comodo = 1;
				}
				if (fgetc(fileOrdini) != EOF) {
					fseek(fileOrdini, -1, SEEK_CUR);
				}
			}
		}
	} else
		printf("Nessun ordine associato a questo account\n");
	if (comodo == 1)
		printf("\nAlla visualizzazione mancano alcuni ordini i cui gadget associati potrebbero essere stati eliminati\n");
}

/**
 * Ricerca gadget nel file
 * @param fileGadget puntatore al file gadget.bin
 * @param nome_gadget nome gadget inserito dall'utente
 * @param codice codice gadget da ricercare
 * @return variabile di controllo della presenza del gadget (perchè potrebbe essere stato eliminato da un venditore)
 */
int ricerca_gadget(FILE *fileGadget, char nome_gadget[], int codice) {
	int trovato = 0;
	gadget pezzo;
	rewind(fileGadget);
	while ((!feof(fileGadget)) && (trovato == 0)) {
		fread(&pezzo, sizeof(gadget), 1, fileGadget);
		if (pezzo.codice == codice) {
			trovato = 1;
			strcpy(nome_gadget, pezzo.nome);
		}
	}
	return trovato;
}

/**
 * Visualizzazione di tutti gli ordini effettuati da tutti i clienti
 * @param fileOrdini puntatore al file ordini.bin
 */
void storico_ordini(FILE *fileOrdini) {
	ordine acquisto = { 0, 0, 0, 0, 0.0, "", "" };
	rewind(fileOrdini);
	if (fgetc(fileOrdini) == EOF) {
		printf("File ordini vuoto\n");
	} else {
		rewind(fileOrdini);
		printf("%-13s %-15s %-15s %-10s %-25s %-30s\n\n", "ID ordine",
				"Codice Gadget", "Codice Cliente", "Ordine",
				"Costo totale in Euro", "Commento");
		while (!feof(fileOrdini)) {
			fread(&acquisto, sizeof(ordine), 1, fileOrdini);
			printf("%-13d %-15d %-15d %-15s %-20.2f %-30s\n\n", acquisto.id,
					acquisto.codice_gadget, acquisto.codice_cliente,
					acquisto.evaso, acquisto.costo, acquisto.commento);
			if (fgetc(fileOrdini) != EOF) {
				fseek(fileOrdini, -1, SEEK_CUR);
			}
		}
	}
}

/**
 * Visualizzazione gadget più venduti
 * @param fileGadget puntatore al file gadget.bin
 */
void statistiche_gadget(FILE *fileGadget) {
	gadget pezzo;
	int venduti[MAX] = { 0 }; //vettore utile per l'ordinamento dei pezzi venduti.
	int i;
	rewind(fileGadget);
	i = 0;
	if (fgetc(fileGadget) == EOF) {
		printf("File gadget vuoto, nessun elemento da stampare\n");
	} else {
		rewind(fileGadget);
		while (!feof(fileGadget)) {
			fread(&pezzo, sizeof(gadget), 1, fileGadget);
			venduti[i++] = pezzo.venduti; //memorizzazione nel vettore dei pezzi venduti di ogni gadget
			if (fgetc(fileGadget) != EOF) {
				fseek(fileGadget, -1, SEEK_CUR);
			}
		}
		merge_sort(venduti, 0, i - 1); //ordinamento vettore venduti[]
		rewind(fileGadget);
		i = 0;
		if (venduti[i] == 0)
			printf("Nessun gadget e' stato acquistato.\n");
		else {
			printf("\nEcco i gadget piu' venduti:\n");
			printf("%-10s %-20s %-40s %-10s %-10s %-20s %-10s\n\n", "Codice",
					"Nome", "Descrizione", "Colore", "Tipologia",
					"Pezzi venduti", "Prezzo");

			while (!feof(fileGadget)) {
				fread(&pezzo, sizeof(gadget), 1, fileGadget);
				if (venduti[i] == pezzo.venduti) { //visualizzazione di tutti i gadget il cui numero di pezzi
												   // venduti è uguale al numero più grande di pezzi venduti.
					printf(" %-10d %-20s %-40s %-10s %-10s %-20d %-10.2f\n\n",
							pezzo.codice, pezzo.nome, pezzo.descrizione,
							pezzo.colore, pezzo.tipologia, pezzo.venduti,
							pezzo.prezzo);
				}
				if (fgetc(fileGadget) != EOF) {
					fseek(fileGadget, -1, SEEK_CUR);
				}
			}
		}
	}
}

/**
 * Ordinamento vettore
 * @param tabella vettore dei pezzi venduti
 * @param inizio indice del vettore che parte dal primo elemento
 * @param fine indice del vettore che parte dall'ultimo elemento
 */
void merge_sort(int tabella[], int inizio, int fine) {
	int medio;
	if (inizio < fine) {
		medio = (inizio + fine) / 2;
		merge_sort(tabella, inizio, medio);
		merge_sort(tabella, medio + 1, fine);
		merge(tabella, inizio, medio, fine);
	}
	return;
}

/**
 * Unione dei due sottovettori ordinati
 * @param tabella vettore dei pezzi venduti
 * @param inizio indice del vettore che punta al primo elemento
 * @param medio indice del vettore che punta all'elemento centrale
 * @param fine indice del vettore che punta all'ultimo elemento
 */
void merge(int tabella[], int inizio, int medio, int fine) {
	int i, j, k = 0, vettore_ordinato[MAX];
	i = inizio;
	j = medio + 1;

	while (i <= medio && j <= fine) {
		if (tabella[i] > tabella[j]) {
			vettore_ordinato[k] = tabella[i];
			i++;
		} else {
			vettore_ordinato[k] = tabella[j];
			j++;
		}
		k++;
	}
	while (i <= medio) {
		vettore_ordinato[k] = tabella[i];
		i++;
		k++;
	}
	while (j <= fine) {
		vettore_ordinato[k] = tabella[j];
		j++;
		k++;
	}
	for (k = inizio; k <= fine; k++)
		tabella[k] = vettore_ordinato[k - inizio];
	return;
}

/**
 * Eliminazione account cliente dal file
 * @param fileClienti puntatore al file clienti.bin
 * @return puntatore al NUOVO file clienti.bin
 */
FILE* elimina_cliente(FILE *fileClienti) {
	cliente utente;
	int indice_nuovo_file;
	FILE *aggiorna;

	indice_nuovo_file = 0;
	aggiorna = fopen("nuovo_clienti.bin", "wb+");
	if (aggiorna == NULL) {
		printf("Impossibile aprire file.\n");
		//apertura (e creazione) di un nuovo file contenente
		// tutti i clienti non eliminati
	} else {
		rewind(fileClienti);
		if (fgetc(fileClienti) == EOF) {
			printf("Nessun cliente registrato\n");
		} else {
			rewind(fileClienti);
			/* Finchè ci sono ancora clienti da posizionare nel nuovo file,
			 viene letto un record dal file clienti.bin e viene
			 effettuato un controllo sul campo userID: infatti il codice del cliente da eliminare è già
			 mantenuto in una variabile globale di sessione.
			 Se lo userID è diverso dall'ID dello user attualmente in sessione (quindi loggato),
			 si inserisce il cliente nel nuovo file e
			 si incrementa il numero di record inseriti in quest'ultimo.
			 Se invece gli ID coincidono, si procede con la lettura di un nuovo record saltando, quindi,
			 solamente quello da eliminare.
			 */
			while (!feof(fileClienti)) {
				fread(&utente, sizeof(cliente), 1, fileClienti); // lettura record dal file
				if (utente.userID != utente_loggato) {
					fseek(aggiorna, indice_nuovo_file * sizeof(cliente),
					SEEK_SET);
					fwrite(&utente, sizeof(cliente), 1, aggiorna);
					indice_nuovo_file++;
				}
				if (fgetc(fileClienti) != EOF) {
					fseek(fileClienti, -1, SEEK_CUR);
				}
			}

			if ((fclose(aggiorna) != 0) || (fclose(fileClienti) != 0))
				printf("Errore in chiusura file.\n");
			printf("\n***ACCOUNT ELIMINATO***\n");
			remove("clienti.bin"); //rimozione file clienti.bin, ormai obsoleto
			rename("nuovo_clienti.bin", "clienti.bin"); //rinominazione file aggiornato in clienti.bin
			fileClienti = aggiorna; //passaggio tra puntatori, in questo modo fileClienti punta
									//al nuovo file, ormai denominato con clienti.bin
			fileClienti = fopen("clienti.bin", "rb+");
			if (fileClienti == NULL) {
				printf("Impossibile aprire file clienti.\n");
			}
		}
	}
	return fileClienti;
}

/**
 * Modifica dati cliente
 * @param fileClienti puntatore al file clienti.bin
 */
void modifica_cliente(FILE *fileClienti) {
	cliente utente;
	rewind(fileClienti);
	if (fgetc(fileClienti) == EOF) {
		printf("Nessun cliente registrato\n");
	} else {
		rewind(fileClienti);
		while (!feof(fileClienti)) {
			fread(&utente, sizeof(cliente), 1, fileClienti);
			if (utente.userID == utente_loggato) {
				printf("Inserimento nuovi dati cliente\n");
				setvbuf(stdin, NULL, _IONBF, 0); //pulisco lo stream
				printf("Password cliente: ");
				gets(utente.password);
				setvbuf(stdin, NULL, _IONBF, 0);
				printf("Nome azienda: ");
				gets(utente.nome);
				setvbuf(stdin, NULL, _IONBF, 0);
				printf("Sede azienda: ");
				gets(utente.sede);
			}
			if (fgetc(fileClienti) != EOF) {
				fseek(fileClienti, -1, SEEK_CUR);
			}
		}
		fseek(fileClienti, -1 * sizeof(cliente), SEEK_CUR);
		fwrite(&utente, sizeof(cliente), 1, fileClienti);
		printf("\n***ACCOUNT MODIFICATO***\n");
	}

}

