/**
 * _______________________________________________________________________________
 *|@file       : menu.c		                       	                              |
 *| File di intestazione delle strutture										  |
 *|@authors    : Gruppo 1 - Emanuele Russo, 735806 - Nicola Mastromarino, 757709  |
 *|@date 27/05/2022																  |
 *|@version 0.1																	  |
 *|_______________________________________________________________________________|
 */

#include "menu.h"
#include "funzioni.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Visualizzazione menu principale
 * @param fileClienti puntatore al file clienti.bin
 * @param fileGadget puntatore al file gadget.bin
 * @param fileVenditori puntatore al file venditori.bin
 * @param fileOrdini puntatore al file ordini.bin
 */
void menu_principale(FILE *fileClienti, FILE *fileVenditori, FILE *fileGadget,
		FILE *fileOrdini) {
	int risposta = 0; // Variabile di lavoro per la scelta del menu
	do {
		do {
			printf(" _____________________________ \n");
			printf("|                             |\n");
			printf("|         MENU INIZIALE       |\n");
			printf("|_____________________________|\n");
			printf("|                             |\n");
			printf("|          1. ACCEDI          |\n");
			printf("|                             |\n");
			printf("|        2. REGISTRATI        |\n");
			printf("|                             |\n");
			printf("|     3. TERMINA PROGRAMMA    |\n");
			printf("|_____________________________|\n\n");

			printf("Digitare il numero dell'operazione da effettuare: \n");
			scanf("%d", &risposta);
		} while ((risposta != 1) && (risposta != 2) && (risposta != 3)); // controllo input

		switch (risposta) {
		case 1:
			menu_accesso(fileVenditori, fileClienti, fileGadget, fileOrdini);
			break;
		case 2:
			menu_registrazione(fileVenditori, fileClienti);
			break;
		case 3:
			break;
		}
	} while (risposta != 3);
}

/**
 * Visualizzazione menu registrazione
 * @param fileVenditori puntatore al file venditori.bin
 * @param fileClienti puntatore al file clienti.bin
 */
void menu_registrazione(FILE *fileVenditori, FILE *fileClienti) {
	int risposta = 0; // Variabile di lavoro per la scelta del menu

	do {
		printf("_________________________________\n");
		printf("|        VUOI REGISTRARTI       |\n");
		risposta = scelta_utente();
	} while ((risposta != 1) && (risposta != 2)); // controllo input
	if (risposta == 1) {
		registra_venditore(fileVenditori);
	} else {
		registra_cliente(fileClienti);
	}
}

/**
 * Visualizzazione menu accesso
 * @param fileVenditori puntatore al file venditori.bin
 * @param fileClienti puntatore al file clienti.bin
 * @param fileGadget puntatore al file gadget.bin
 * @param fileOrdini puntatore al file ordini.bin
 */
void menu_accesso(FILE *fileVenditori, FILE *fileClienti, FILE *fileGadget,
		FILE *fileOrdini) {
	int risposta = 0; // Variabile di lavoro per la scelta del menu
	// apertura file binari
	fileVenditori = fopen("venditori.bin", "rb+");
	fileClienti = fopen("clienti.bin", "rb+");
	fileGadget = fopen("gadget.bin", "rb+");
	fileOrdini = fopen("ordini.bin", "rb+");
	if ((fileVenditori == NULL) || (fileClienti == NULL) || (fileGadget == NULL)
			|| (fileOrdini == NULL))
		printf("Errore in apertura file.\n");
	else {
		do {
			printf("_________________________________\n");
			printf("|             ACCEDI            |\n");
			risposta = scelta_utente();
		} while ((risposta != 1) && (risposta != 2)); // controllo input
		if (risposta == 1) {
			accesso_venditore(fileVenditori);
			menu_venditore(fileVenditori, fileClienti, fileGadget, fileOrdini);
		} else {
			accesso_cliente(fileClienti);
			menu_cliente(fileClienti, fileGadget, fileOrdini);
		}
		if ((fclose(fileVenditori) != 0) || (fclose(fileClienti) != 0)
				|| (fclose(fileGadget) != 0) || (fclose(fileOrdini) != 0))
			printf("Errore in chiusura file.\n");
	}
}

/**
 * Visualizzazione menu di scelta tra venditore e cliente
 * @return scelta effettuata dall'utente
 */
int scelta_utente() {
	int scelta = 0;
	printf("|                               |\n");
	printf("|              COME:            |\n");
	printf("|_______________________________|\n");
	printf("|                               |\n");
	printf("|          1. VENDITORE         |\n");
	printf("|                               |\n");
	printf("|           2. CLIENTE          |\n");
	printf("|_______________________________|\n\n");

	scelta = input_intero(
			"Digitare il numero della modalit� di accesso o registrazione: ");
	return scelta;
}

/**
 * Visualizzazione menu venditore
 * @param fileVenditori puntatore al file venditori.bin
 * @param fileClienti puntatore al file clienti.bin
 * @param fileGadget puntatore al file gadget.bin
 * @param fileOrdini puntatore al file ordini.bin
 */
void menu_venditore(FILE *fileVenditori, FILE *fileClienti, FILE *fileGadget,
		FILE *fileOrdini) {
	int scelta = 0; // Variabile di lavoro per la scelta del menu
	do {
		do {
			printf(" _____________________________ \n");
			printf("|                             |\n");
			printf("|         MENU VENDITORE      |\n");
			printf("|_____________________________|\n");
			printf("|                             |\n");
			printf("|      1. AGGIUNGI GADGET     |\n");
			printf("|      2. MODIFICA GADGET     |\n");
			printf("|      3. ELIMINA GADGET      |\n");
			printf("|      4. STORICO ORDINI      |\n");
			printf("|      5. CLIENTI REGISTRATI  |\n");
			printf("|          6. LOGOUT          |\n");
			printf("|      7. TERMINA PROGRAMMA   |\n");
			printf("|_____________________________|\n\n");

			scelta = input_intero("Digitare il numero dell'operazione da effettuare: ");
		} while ((scelta < 1) || (scelta > 7));
		// controllo input
		switch (scelta) {
		case 1:
			aggiungi_gadget(fileVenditori, fileGadget);
			break;
		case 2:
			modifica_gadget(fileVenditori, fileGadget);
			break;
		case 3:
			fileGadget = elimina_gadget(fileGadget);
			break;
		case 4:
			storico_ordini(fileOrdini);
			break;
		case 5:
			visualizza_cliente(fileClienti);
			break;
		case 6:
			printf("Logout in corso...\nA presto!\n");
			break;
		case 7:
			// chiusura file
			if ((fclose(fileVenditori) != 0) || (fclose(fileClienti) != 0)
					|| (fclose(fileGadget) != 0) || (fclose(fileOrdini) != 0))
				printf("Errore in chiusura file.\n");
			chiusura_programma();
			break;

		}
	} while ((scelta != 6) && (scelta != 7));
}

/**
 * Visualizzazione menu clienti
 * @param fileClienti puntatore al file clienti.bin
 * @param fileGadget puntatore al file gadget.bin
 * @param fileOrdini puntatore al file ordini.bin
 */
void menu_cliente(FILE *fileClienti, FILE *fileGadget, FILE *fileOrdini) {
	int scelta = 0; // Variabile di lavoro per la scelta del menu
	do {
		do {
			printf(" _____________________________ \n");
			printf("|                             |\n");
			printf("|         MENU CLIENTE        |\n");
			printf("|_____________________________|\n");
			printf("|                             |\n");
			printf("|      1. NUOVO ORDINE        |\n");
			printf("|      2. ORDINI EFFETTUATI   |\n");
			printf("|      3. STATISTICHE GADGET  |\n");
			printf("|      4. ELIMINA ACCOUNT     |\n");
			printf("|      5. MODIFICA ACCOUNT    |\n");
			printf("|          6. LOGOUT          |\n");
			printf("|      7. TERMINA PROGRAMMA   |\n");
			printf("|_____________________________|\n\n");

			scelta = input_intero("Digitare il numero dell'operazione da effettuare: ");
		} while ((scelta < 1) || (scelta > 7));
		switch (scelta) {
		case 1:
			effettua_ordine(fileClienti, fileOrdini, fileGadget);
			break;
		case 2:
			visualizza_i_tuoi_ordini(fileOrdini, fileGadget);
			break;
		case 3:
			statistiche_gadget(fileGadget);
			break;
		case 4:
			fileClienti = elimina_cliente(fileClienti);
			break;
		case 5:
			modifica_cliente(fileClienti);
			break;
		case 6:
			printf("Logout in corso...\nA presto!\n");
			break;
		case 7:
			// chiusura file
			if ((fclose(fileClienti) != 0) || (fclose(fileGadget) != 0)
					|| (fclose(fileOrdini) != 0))
				printf("Errore in chiusura file.\n");
			chiusura_programma();
			break;

		}
	} while ((scelta != 4) && (scelta != 6) && (scelta != 7));
}
