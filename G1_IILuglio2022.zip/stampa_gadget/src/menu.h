/**
 * _______________________________________________________________________________
 *|@file       : menu.h                  	     	                              |
 *| File di intestazione delle strutture										  |
 *|@authors    : Gruppo 1 - Emanuele Russo, 735806 - Nicola Mastromarino, 757709  |
 *|@date 27/05/2022																  |
 *|@version 0.1																	  |
 *|_______________________________________________________________________________|
 */

#include <stdio.h>

/**
 * Visualizzazione menu principale
 * @param fileClienti puntatore al file clienti.bin
 * @param fileGadget puntatore al file gadget.bin
 * @param fileVenditori puntatore al file venditori.bin
 * @param fileOrdini puntatore al file ordini.bin
 */
void menu_principale(FILE *fileClienti, FILE *fileVenditori, FILE *fileGadget,
		FILE *fileOrdini);

/**
 * Visualizzazione menu accesso
 * @param fileVenditori puntatore al file venditori.bin
 * @param fileClienti puntatore al file clienti.bin
 * @param fileGadget puntatore al file gadget.bin
 * @param fileOrdini puntatore al file ordini.bin
 */
void menu_accesso(FILE *fileVenditori, FILE *fileClienti, FILE *fileGadget,
		FILE *fileOrdini);

/**
 * Visualizzazione menu registrazione
 * @param fileVenditori puntatore al file venditori.bin
 * @param fileClienti puntatore al file clienti.bin
 */
void menu_registrazione(FILE *fileVenditori, FILE *fileClienti);

/**
 * Visualizzazione menu di scelta tra venditore e cliente
 * @return scelta effettuata dall'utente
 */
int scelta_utente();

/**
 * Visualizzazione menu venditore
 * @param fileVenditori puntatore al file venditori.bin
 * @param fileClienti puntatore al file clienti.bin
 * @param fileGadget puntatore al file gadget.bin
 * @param fileOrdini puntatore al file ordini.bin
 */
void menu_venditore(FILE *fileVenditori, FILE *fileClienti, FILE *fileGadget,
		FILE *fileOrdini);

/**
 * Visualizzazione menu clienti
 * @param fileClienti puntatore al file clienti.bin
 * @param fileGadget puntatore al file gadget.bin
 * @param fileOrdini puntatore al file ordini.bin
 */
void menu_cliente(FILE *fileClienti, FILE *fileGadget, FILE *fileOrdini);
